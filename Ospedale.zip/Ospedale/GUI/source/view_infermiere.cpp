#include "../header/view_infermiere.h"

view_infermiere:: ~view_infermiere() {}

void view_infermiere::edit() const{
    view_persona::edit();

}

void view_infermiere::build_field(){
    view_persona::build_field();

}
