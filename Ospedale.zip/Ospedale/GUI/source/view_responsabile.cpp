#include "../header/view_responsabile.h"

view_responsabile:: ~view_responsabile() {}


void view_responsabile::edit() const{
    view_persona::edit();

}

void view_responsabile::build_field(){
    view_persona::build_field();

}

